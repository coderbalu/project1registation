import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.PrintWriter;

import java.io.IOException;
import java.sql.*;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String fatherName = request.getParameter("fatherName");
        String motherName = request.getParameter("motherName");
        String ageStr = request.getParameter("age");
        String dob = request.getParameter("dob");
        String phone = request.getParameter("phone");
        String email = request.getParameter("email");

        int age = Integer.parseInt(ageStr);

        // JDBC code
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/project1", "root", "root"
            );

            String sql = "INSERT INTO student (first_name, last_name, father_name, mother_name, age, dob, phone, email) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, firstName);
            ps.setString(2, lastName);
            ps.setString(3, fatherName);
            ps.setString(4, motherName);
            ps.setInt(5, age);
            ps.setString(6, dob);  // assuming dob format is yyyy-MM-dd
            ps.setString(7, phone);
            ps.setString(8, email);

            int rowsInserted = ps.executeUpdate();

            if (rowsInserted > 0) {
                out.println("<html><body style='font-family:sans-serif;'>");
                out.println("<h2>Thank you for registering!</h2>");
                out.println("<p>Name: <strong>" + firstName + " " + lastName + "</strong></p>");
                out.println("<p>Father's Name: <strong>" + fatherName + "</strong></p>");
                out.println("<p>Mother's Name: <strong>" + motherName + "</strong></p>");
                out.println("<p>Age: <strong>" + age + "</strong></p>");
                out.println("<p>Date of Birth: <strong>" + dob + "</strong></p>");
                out.println("<p>Phone: <strong>" + phone + "</strong></p>");
                out.println("<p>Email: <strong>" + email + "</strong></p>");
                out.println("</body></html>");
            } else {
                out.println("<p>Error: Failed to register user.</p>");
            }

            conn.close();
        } catch (Exception e) {
            out.println("<p>Error: " + e.getMessage() + "</p>");
            e.printStackTrace(out);
        }
    }
}
